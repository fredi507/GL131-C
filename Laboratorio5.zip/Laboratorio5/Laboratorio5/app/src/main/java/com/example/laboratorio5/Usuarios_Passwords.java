package com.example.laboratorio5;
import java.util.ArrayList;

public class Usuarios_Passwords {

    public ArrayList<String> agregardatos(ArrayList<String> arrayList, String correo, String contra) {

        arrayList.add(correo);
        arrayList.add(contra);

        return arrayList;
    }

    public int validardatos(ArrayList<String> lista, String usuario, String pass){

        for(int i = 0; i < lista.size() - 1; i++){

            if (lista.get(i).equals(usuario) && lista.get(i+1).equals(pass)) {
                return 1;
            }
        }

        return 0;
    }



    public boolean buscarParametro(ArrayList<String> lista, String parametro) {
        for (String elemento : lista) {
            if (elemento.equals(parametro)) {
                return true; // El parámetro fue encontrado en la lista
            }
        }
        return false; // El parámetro no se encontró en la lista
    }




}
