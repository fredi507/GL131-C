package com.example.laboratorio5;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class RegistroActivity extends AppCompatActivity {

    private EditText nombre;
    private EditText cedula;
    private EditText correo;

    private EditText password;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        nombre = (EditText)findViewById(R.id.usernameEditText);
        cedula = (EditText)findViewById(R.id.ceduserEditText);
        correo = (EditText)findViewById(R.id.usernameEditText2);
        password = (EditText)findViewById(R.id.passwordEditText2);

    }

    public void iniciarsesion(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void registrar(View view) {
        Intent intent = new Intent(this, MainActivity.class);

        try {

            if (!TextUtils.isEmpty(nombre.getText().toString()) && !TextUtils.isEmpty(cedula.getText().toString()) && !TextUtils.isEmpty(correo.getText().toString()) && !TextUtils.isEmpty(password.getText().toString()) ){

                String name = nombre.getText().toString();
                String ced = cedula.getText().toString();
                String corre = correo.getText().toString();
                String pass = password.getText().toString();


                intent.putExtra("nombre", name);
                intent.putExtra("cedula", ced);
                intent.putExtra("correo", corre);
                intent.putExtra("contra", pass);
                startActivity(intent);
            }
            else {
                Toast.makeText(getApplicationContext(), "Los campos no pueden quedar vacios", Toast.LENGTH_SHORT).show();
            }

        }catch (Exception e){}


    }

}