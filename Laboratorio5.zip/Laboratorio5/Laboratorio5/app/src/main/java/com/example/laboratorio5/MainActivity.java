package com.example.laboratorio5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity {

    private TextView prueba;
    private TextView prueba2;
    private EditText usuario;
    private EditText contrasena;


    private ArrayList<String> cuentas = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Usuarios_Passwords obj = new Usuarios_Passwords();
        incializarcontroles();


        String correo = getIntent().getStringExtra("correo");
        String password = getIntent().getStringExtra("contra");

        if (correo != null && password != null ) {

            prueba.setText(correo);

           cuentas = obj.agregardatos(cuentas,correo,password);

           prueba2.setText(cuentas.get(1));

        }

    }

    public void incializarcontroles(){
        prueba = (TextView)findViewById(R.id.pruebatexto);
        prueba2 = (TextView)findViewById(R.id.pruebatexto2);
        usuario = (EditText)findViewById(R.id.usernameEditText);
        contrasena = (EditText)findViewById(R.id.passwordEditText);
    }

    public void infogrupo(View view) {
        Intent intent = new Intent(this, Informacion_activity.class);

        try {

            if (!TextUtils.isEmpty(usuario.getText().toString()) && !TextUtils.isEmpty(contrasena.getText().toString())){
                Usuarios_Passwords obj = new Usuarios_Passwords();

                int resultado = obj.validardatos(cuentas,usuario.getText().toString(),contrasena.getText().toString());

                prueba.setText(String.valueOf(resultado));

                if(resultado==1){
                    startActivity(intent);
                } else if (resultado==0) {
                    Toast.makeText(getApplicationContext(), "Usuario y/o contraseña incorrectos, inténtalo denuevo", Toast.LENGTH_SHORT).show();
                }


            }
            else {
                Toast.makeText(getApplicationContext(), "Los campos no pueden quedar vacios", Toast.LENGTH_SHORT).show();
            }

        }catch (Exception e){}

    }

    public void registro(View view) {
        Intent intent = new Intent(this, RegistroActivity.class);
        startActivity(intent);
    }


}